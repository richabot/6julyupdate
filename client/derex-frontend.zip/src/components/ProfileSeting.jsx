import React, { useState } from 'react'
import ProfileUpdate from './ProfileUpdate'
// import AccountInformtation from './Profiles/AccountInformtation';

const ProfileSeting = () => {
  
  return (
    <div >
    
    </div>
  )
}

export default ProfileSeting