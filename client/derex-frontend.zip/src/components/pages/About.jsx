import React from 'react';
import ProfileUpdate from '../ProfileUpdate';
import Navbarnav from './Navbarnav';

const About = () => {
    return (
        <div>
            <ProfileUpdate />
        </div>
    );
};

export default About;