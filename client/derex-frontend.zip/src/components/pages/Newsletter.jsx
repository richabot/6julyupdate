import React from 'react';

const Newsletter = () => {
    return (
        <div>
            <h1>product page</h1>
        </div>
    );
};

export default Newsletter;