import React, { useEffect, useState } from 'react';


const Dashboard = ({ user }) => {
  console.log(user, "uieie")

  return <div>Dashboard</div>;
};

export default Dashboard;
