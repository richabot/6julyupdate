import React from 'react';
import Setup from '../Setup';

const Security = () => {
    return (
        <div>
           <Setup/>
        </div>
    );
};

export default Security;