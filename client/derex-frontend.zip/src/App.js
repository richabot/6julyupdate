// import React, { Component } from "react";
// import jwtDecode from "jwt-decode";
// import NavBar from "./components/navbar";
// import LoginForm from "./components/loginForm";
// import LogOut from "./components/logout";
// import RegisterForm from "./components/registerForm";
// import HomePage from "./components/homePage";
// import PasswordResetForm from "./components/resetPasswordForm";
// import PasswordResetReceivedForm from "./components/passResetReceivedForm";
// import { Navigate, Redirect, Route, Routes, Switch } from "react-router-dom";
// import "./App.css";
// import Dashboard from "./components/pages/Dashboard";
// import Profile from "./components/Profile";
// import Setup from "./components/Setup";
// import Otp from "./components/Otp";
// import { connect } from 'react-redux';
// import Reduxcheck from "./components/Reduxcheck";
// import Sidebar from "./components/Sidebar";
// import About from './components/pages/About';
// import Comment from './components/pages/Comment';
// import Analytics from './components/pages/Analytics';
// import Product from './components/pages/Product';
// import ProductList from './components/pages/ProductList';


// class App extends Component {
//   state = {};

//   componentDidMount() {
//     try {
//       const jwt = localStorage.getItem("token");
//       const logged = localStorage.getItem("loggedin");

//       const user = jwtDecode(jwt);
//       console.log(user);
//       this.setState({ user });
//       this.setState({ logged });

//     } catch (ex) { }
//   }
   
//   render() {
//     const { user, logged } = this.state;
//     console.log(user, logged, "details to be send")
//     const isUserLoggedIn = user && logged == "true";
//     console.log(isUserLoggedIn, "is logged in")
//     console.log(user, logged, "creds to display")

//     return (
//       <React.Fragment>
//         <NavBar user={this.state.user} logged={this.state.logged} authenticated={isUserLoggedIn} />
//         <main >
//           <Routes>

//             <Route
//               path="/users/reset_password_received/:userId/:token"
//               render={({ match }) => (
//                 <PasswordResetReceivedForm
//                   userId={match.params.userId}
//                   token={match.params.token}
//                 />
//               )}
//             />
//             {isUserLoggedIn && <Route
//               path="/dashboard"
//               render={() => (isUserLoggedIn ? <Dashboard /> : <Navigate to="/login" />)}
//             />

//             }

//             {
//               isUserLoggedIn && <Route path="/logout" component={<LogOut/>} />
//             }
//             <Route path="/users/reset_password" component={PasswordResetForm} />
//             <Route path="/login" component={LoginForm} />

//             <Route path="/register" component={RegisterForm} />
//             <Route path="/profile" component={Profile} />
//             <Route path="/setup" component={Setup} />
//             <Route path="/otp" component={Otp} />
//             <Route path="/getdata" component={Reduxcheck} />
//             {/* <Route
//               path="/"
//               render={() => <HomePage user={this.state.user} />}
//             /> */}
//             {/* <Route
//               path="/"
//               component={HomePage}
//             /> */}

//           </Routes>
//           <Sidebar>
//         <Routes>
          
//         {
//               isUserLoggedIn && <Route path="/logout" component={LogOut} />
//             }
//           <Route path="/" element={<Dashboard />} />
//           <Route path="/dashboard" element={<Dashboard />} />
//           <Route path="/about" element={<About />} />
//           <Route path="/comment" element={<Comment />} />
//           <Route path="/analytics" element={<Analytics />} />
//           <Route path="/product" element={<Product />} />
//           <Route path="/productList" element={<ProductList />} />
//         </Routes>
//       </Sidebar>
//         </main>
     
//       </React.Fragment>
//     );
//   }
// }

// export default App;

import React, { Component } from "react";
import jwtDecode from "jwt-decode";
import { Navigate, Route, Routes } from "react-router-dom";
import NavBar from "./components/navbar";
import LoginForm from "./components/loginForm";
import LogOut from "./components/logout";
import RegisterForm from "./components/registerForm";
import HomePage from "./components/homePage";
import PasswordResetForm from "./components/resetPasswordForm";
import PasswordResetReceivedForm from "./components/passResetReceivedForm";
import "./App.css";
import Dashboard from "./components/pages/Dashboard";
import Profile from "./components/Profile";
import Setup from "./components/Setup";
import Otp from "./components/Otp";
import { connect } from 'react-redux';
import Reduxcheck from "./components/Reduxcheck";
import Sidebar from "./components/Sidebar";
import About from './components/pages/About';
import Comment from './components/pages/Security';
import Analytics from './components/pages/AccountInfo';
import Product from './components/pages/Newsletter';
import ProductList from './components/pages/ProductList';
import Security from "./components/pages/Security";
import Newsletter from "./components/pages/Newsletter";
import AccountInfo from "./components/pages/AccountInfo";

class App extends Component {
  state = {
    user: null,
    logged: false
  };

  componentDidMount() {
    try {
      const jwt = localStorage.getItem("token");
      const logged = localStorage.getItem("loggedin");

      const user = jwtDecode(jwt);
      console.log(user);
      this.setState({ user, logged });

    } catch (ex) { }
  }

  render() {
    const { user, logged } = this.state;
    const isUserLoggedIn = user && logged === "true";

    return (
      <>
        <NavBar user={this.state.user} logged={this.state.logged} authenticated={isUserLoggedIn} />
       
          <Routes>
            <Route
              path="/users/reset_password_received/:userId/:token"
              element={<PasswordResetReceivedForm />}
            />
           
            {
              isUserLoggedIn && <Route path="/logout" element={<LogOut/>} />
            }
            <Route path="/login" element={<LoginForm />} />
            <Route path="/register" element={<RegisterForm />} />
            {/* <Route path="/profile" element={<Profile />} /> */}
            <Route path="/setup" element={<Setup />} />
            <Route path="/otp" element={<Otp />} />
            <Route path="/getdata" element={<Reduxcheck />} />
            <Route path="/users/reset_password" element={<PasswordResetForm />} />
            {/* <Route path="/" element={<HomePage user={this.state.user} />} /> */}
           
          </Routes>
        { isUserLoggedIn && <Sidebar>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/profile" element={<About />} />
              <Route path="/profile/account" element={<AccountInfo />} />
              <Route path="/profile/security" element={<ProductList />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/profile/newletter" element={<Newsletter />} />
              <Route path="/productList" element={<ProductList />} />
            </Routes>
          </Sidebar>}
      
      </>
    );
  }
}

export default App;
