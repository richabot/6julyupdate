import React, { useEffect, useState } from 'react'

const ProfileUpdate = () => {
  const email = localStorage.getItem('email');
  console.log("local", email)
  const [updatedDetails, setUpdatedDetails] = useState(null);
  useEffect(() => {
    console.log(email, "locastorage")
    const fetchUserDetails = async () => {

      try {
        const response = await fetch(`http://localhost:5000/api/users/data/${email}`);
        const data = await response.json();
        console.log(data, "sucessd data")
        setUpdatedDetails(data);
      } catch (error) {
        console.log(error, "error");
      }
    };

    fetchUserDetails();
  }, []);

  const handleChange = (e) => {
    setUpdatedDetails({
      ...updatedDetails,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    console.log("handlesubmit")
    console.log(updatedDetails, "update details")
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/users/profile/profileUpdate', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedDetails),
      });
      const data = await response.json();
      console.log('Data updated successfully:', data);
    } catch (error) {
      console.log(error);
    }
  };

  return (

    <div>

      {console.log(updatedDetails, "user details")}


      {updatedDetails && <form onSubmit={handleSubmit}>
        <div className='personalbox1'>
          <h5>Richa Shah</h5>
          <p>richagshah03@gmail.com</p>
        </div>
        <div>
          <h6 style={{ marginLeft: "28px" }}>client</h6>
          <div className='personalbox1 personalbox2'>
            <div className='input-row'>
              <div className='input-group'>
                <label htmlFor='firstName'>First Name:</label>
                <input type="text"
                  name="firstName"
                  value={updatedDetails.firstName}
                  onChange={handleChange} />
              </div>
              <div className='input-group'>
                <label htmlFor='lastName'>Last Name:</label>
                <input type="text"
                  name="lastName"
                  value={updatedDetails.lastName}
                  onChange={handleChange} />
              </div>
            </div>
            <div className='input-row'>
              <div className='input-group'>
                <label htmlFor='title'>Title:</label>
                <input type="text" name="title" value={updatedDetails.title} onChange={handleChange} />
              </div>
              <div className='input-group'>
                <label htmlFor='title'>Username:</label>
                <input type="text"
                  name="username"
                  value={updatedDetails.username}
                  onChange={handleChange} />
              </div>

            </div>
          </div>
        </div>


        <div>
          <h6 style={{ marginLeft: "28px" }}>Contact Info</h6>
          <div className='personalbox1 personalbox2 personalbox3'>
            <div className='input-row'>
              <div className='input-group'>
                <label htmlFor='firstName'>Contact Phone</label>
                <input type="text" name="contact" value={updatedDetails.contact} onChange={handleChange} />
              </div>
              <div className='input-group'>
                <label htmlFor='lastName'>Email address:</label>
                <input type="email" name="email" value={updatedDetails.email} disabled />
              </div>
            </div>
            <div className='input-row'>
              <div className='input-group'>
                <label htmlFor='title'>Country:</label>
                <input type="text" name="country" value={updatedDetails.country} onChange={handleChange} />
              </div>
              <div className='input-group'>
                <label htmlFor='title'>State:</label>
                <input type="text" name="state" value={updatedDetails.state} onChange={handleChange} />
              </div>
            </div>
            <div className='input-row'>
              <div className='input-group'>
                <label htmlFor='title'>Street:</label>
                <input type="text" name="street" value={updatedDetails.street} onChange={handleChange} />
              </div>
              <div className='input-group'>
                <label htmlFor='title'>City:</label>
                <input type="text" name="city" value={updatedDetails.city} onChange={handleChange} />
              </div>
            </div>
            <div className='input-group'>
              <label htmlFor='title'>Postal code:</label>
              <input type="text" name="postalcode" value={updatedDetails.postalcode} onChange={handleChange} />
            </div>
          </div>
        </div>

        <button type="submit" className='profiletab1Save'>Save </button>
      </form>}

    </div>


  )
}

export default ProfileUpdate